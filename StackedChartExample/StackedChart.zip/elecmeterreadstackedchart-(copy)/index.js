//get siteid of the current site
var site_id = themeDisplay.getSiteGroupId();
//get current url of the page
var currentUrl = Liferay.currentURL;
//get base url oof the site
var currentSiteUrl = themeDisplay.getPortalURL();
//rest API url to get all content related to object type "reading"
var url_getLastMonthReading = currentSiteUrl +"/o/c/readings/scopes/"+site_id+"?pageSize=400&sort=dateCreated:desc";
//Variables Definitions and values
var readingATitle = "Var A";
var readingBTitle = "Var B";
var readingCTitle = "Var C";
var readingDTitle = "Var D";
var sYAxisName = "Axis Y Var 2";
var pYAxisName = "Axis Y";
var xAxisName = "Axis X";
var chartCaption="Utilities Consumption";

/*
Function to fetch the data from rest API, Calltype is "GET/POST/PUT" etc, CAll URL is the rest API url to be passed. 
It inturn call loadObjectStackedChartif the API call return valid Response
*/
function restAPICallObjectStackedChart(callType, CallUrl, CallData){
	//Rest API call for the url passed
    Liferay.Util.fetch(
        CallUrl, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json; charset=utf8'
            },
            method: callType,
        }
    )
    .then((response) => response.json())
    .then((data) => {
			// call loadObjectStackedChart function if the API response is valid 
			loadObjectStackedChart(data.items);
    })
    .catch((error) => {
        console.log(error);
        Liferay.Util.openToast({
            message: 'An error occured.',
            type: 'danger',
        });
    });
}

//Function that process the response data from rest api and creates Chart
function loadObjectStackedChart(result_getLastMonthReading){
var arrReadings = [];
//loop the data passed
for (var key_getLastMonthReading in result_getLastMonthReading) {
	if (result_getLastMonthReading.hasOwnProperty(key_getLastMonthReading)) {
		//variable definitions and values
		var billDate = result_getLastMonthReading[key_getLastMonthReading].month +" "+ result_getLastMonthReading[key_getLastMonthReading].year;
		var readingA = result_getLastMonthReading[key_getLastMonthReading].readingA;
		var readingB = result_getLastMonthReading[key_getLastMonthReading].readingB;
		var readingC = result_getLastMonthReading[key_getLastMonthReading].readingC;
		var readingD = result_getLastMonthReading[key_getLastMonthReading].readingD;
		var billDt = billDate;
		//creates a multidimentional structured array and append values to it
		var newArr = [billDt, readingATitle, readingA];
		arrReadings.push(newArr);
		var newArr = [billDt, readingBTitle, readingB];
		arrReadings.push(newArr);
		var newArr = [billDt, readingCTitle, readingC];
		arrReadings.push(newArr);
	}
}
//schema to be passed to fusion chart function 
const data = arrReadings;
    const schema = [{
      "name": "Date",
      "type": "date"
    },
    {
      "name": "Period of the day",
      "type": "string",
			"paletteColor": "#29c3be"
    },
    {
      "name": "Consumption",
      "type": "number",
			"paletteColor": "#f1f718"
    }
    ];
  
    const dataStore = new FusionCharts.DataStore();
    const dataSource = {
      chart: {"canvasBgAlpha":"100", "legendBgAlpha":"100", "bgAlpha":"100"},
			"canvasBgAlpha":"100", "legendBgAlpha":"100", "bgAlpha":"100",
      caption: {
        text: ""
      },
      subcaption: {
        text: ""
      },
      series: "Period of the day",
      navigator: {
        enabled: 0
      },
       xAxis: {
           binning: {
              year: [],
              month: [1],
              day: [],
              hour: [],
              minute: [],
              second: [],
              millisecond: [],
           },
        },
      yaxis: [
        {
          plot: [
            {
              value: "Consumption",
              type: "column"
            }
          ],
          title: "",
          format: {
            suffix: ""
          }
        }
      ]
    };
	
	//passing the data nad schema to create a data structure
    dataSource.data = dataStore.createDataTable(data, schema);
  //Creates fusionchart with created datasource
    new FusionCharts({
      type: "timeseries",
      renderAt: "ObjectStackedChart",
			containerBackgroundOpacity:0,
      width: "100%",
      height: "500",
      dataSource: dataSource
    }).render();
}
// Call to the rest API function to fetch the data on page load
restAPICallObjectStackedChart("GET", url_getLastMonthReading, "");